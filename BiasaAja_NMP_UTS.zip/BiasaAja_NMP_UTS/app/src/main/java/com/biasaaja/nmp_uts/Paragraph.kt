package com.biasaaja.nmp_uts

class Paragraph (val id:Int, val cerbung:Int, val author:String, val paragraph:String) {

}